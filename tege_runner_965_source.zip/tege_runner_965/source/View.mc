using Toybox.Activity;
using Toybox.Application;
using Toybox.Graphics;
using Toybox.Lang;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;
using Toybox.WatchUi;

class TegeRunnerView extends WatchUi.WatchFace {
    const BG = 0x080D15;
    const TURQUOISE = 0x35E4D7;
    const WHITE = 0xFFFFFF;
    const RED = 0xFF455B;
    const YELLOW = 0xFFE44D;
    const BLUE = 0x35C9F0;

    function initialize() {
        WatchFace.initialize();
    }

    function onUpdate(dc) {
        var w = dc.getWidth();
        var h = dc.getHeight();
        var cx = w / 2;
        var cy = h / 2;
        var now = Gregorian.info(Time.now(), Time.FORMAT_MEDIUM);
        var timeInfo = System.getClockTime();
        var hour = timeInfo.hour.format("%02d");
        var minute = timeInfo.min.format("%02d");
        var dateText = now.month.format("%d") + "月" + now.day.format("%d") + "日";
        var battery = System.getSystemStats().battery;
        var monitor = Activity.getActivityInfo();
        var steps = monitor == null ? 0 : monitor.steps;

        dc.setColor(BG, BG);
        dc.clear();
        dc.setPenWidth(4);
        dc.setColor(TURQUOISE, BG);
        dc.drawCircle(cx, cy, (w / 2) - 12);

        dc.setColor(WHITE, BG);
        dc.drawText(cx, cy - 145, Graphics.FONT_MEDIUM, dateText, Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(cx, cy - 83, Graphics.FONT_NUMBER_THAI_HOT, hour + ":" + minute, Graphics.TEXT_JUSTIFY_CENTER);

        dc.setPenWidth(2);
        dc.setColor(TURQUOISE, BG);
        dc.drawLine(42, cy - 48, w - 42, cy - 48);

        dc.setColor(RED, BG);
        dc.drawText(cx - 105, cy - 15, Graphics.FONT_MEDIUM, "♥", Graphics.TEXT_JUSTIFY_CENTER);
        dc.setColor(WHITE, BG);
        dc.drawText(cx - 65, cy - 15, Graphics.FONT_SMALL, "心拍", Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(cx + 5, cy - 15, Graphics.FONT_SMALL, "気温", Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(cx + 112, cy - 15, Graphics.FONT_SMALL, "湿度", Graphics.TEXT_JUSTIFY_CENTER);
        dc.setColor(RED, BG);
        dc.drawText(cx - 65, cy + 18, Graphics.FONT_MEDIUM, "-- bpm", Graphics.TEXT_JUSTIFY_CENTER);
        dc.setColor(YELLOW, BG);
        dc.drawText(cx + 5, cy + 18, Graphics.FONT_MEDIUM, "--°C", Graphics.TEXT_JUSTIFY_CENTER);
        dc.setColor(BLUE, BG);
        dc.drawText(cx + 112, cy + 18, Graphics.FONT_MEDIUM, "--%", Graphics.TEXT_JUSTIFY_CENTER);

        dc.setColor(TURQUOISE, BG);
        dc.drawLine(42, cy + 48, w - 42, cy + 48);
        dc.setColor(WHITE, BG);
        dc.drawText(cx - 65, cy + 72, Graphics.FONT_SMALL, "歩数", Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(cx - 65, cy + 99, Graphics.FONT_MEDIUM, steps.format("%d"), Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(cx + 90, cy + 72, Graphics.FONT_SMALL, "電池", Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(cx + 90, cy + 99, Graphics.FONT_MEDIUM, battery.format("%.0f") + "%", Graphics.TEXT_JUSTIFY_CENTER);

        dc.setColor(TURQUOISE, BG);
        dc.drawText(cx, cy + 137, Graphics.FONT_SMALL, "MONTHLY RUNNING", Graphics.TEXT_JUSTIFY_CENTER);
        dc.setColor(TURQUOISE, BG);
        dc.drawText(cx - 76, cy + 170, Graphics.FONT_MEDIUM, "--.- km", Graphics.TEXT_JUSTIFY_CENTER);
        dc.setColor(YELLOW, BG);
        dc.drawText(cx + 83, cy + 170, Graphics.FONT_MEDIUM, "-- 回", Graphics.TEXT_JUSTIFY_CENTER);
        dc.setColor(WHITE, BG);
        dc.drawText(cx - 76, cy + 194, Graphics.FONT_XTINY, "月間距離", Graphics.TEXT_JUSTIFY_CENTER);
        dc.drawText(cx + 83, cy + 194, Graphics.FONT_XTINY, "月間回数", Graphics.TEXT_JUSTIFY_CENTER);
    }
}
