Tege Runner 965 - Garmin Forerunner 965向けウォッチフェイス試作

設定
- 背景: ダークネイビー/ブラック
- アクセント: ターコイズ
- 時刻: 24時間表示
- 対象: Forerunner 965 (fr965)

重要
このフォルダは初期ソースコードです。Garmin Connect IQ SDKでのコンパイル・実機検証はまだ行っていません。
そのため、現時点でPRGファイルではなく、開発用プロジェクトです。

現時点の実装方針
- 時刻、日付、歩数、バッテリーを表示する試作画面
- 心拍数、気温、湿度はAPI/データ取得方式の実装が必要なため仮表示
- 月間走行距離・回数は自動連携の仕組みが未実装のため仮表示

自動連携について
Garmin Connect Developer ProgramのPersonal向けアクセスは、個人が自身のActivity/Healthデータを取得する選択肢として案内されています（Pull方式）。ただしAPI利用登録・認証と、取得データを時計へ渡す仕組みが別途必要です。
ウォッチフェイス単体でGarmin Connectの月間集計値を直接読む機能ではありません。

ビルドの基本
1. PCまたは対応するクラウド開発環境でGarmin Connect IQ SDKを用意
2. Monkey Cプロジェクトとして開く
3. Forerunner 965向けにビルド
4. コンパイルエラーを修正し、実機でレイアウトと電池消費を確認

公式資料
https://developer.garmin.com/connect-iq/sdk/
https://developer.garmin.com/connect-iq/connect-iq-basics/your-first-app/
https://developer.garmin.com/gc-developer-program/overview/
